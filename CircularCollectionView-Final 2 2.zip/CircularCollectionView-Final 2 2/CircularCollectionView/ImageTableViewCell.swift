//
//  ImageTableViewCell.swift
//  ParseTesting
//
//  Created by Madeline Gilbert on 11/23/15.
//  Copyright © 2015 Kayla Kerney. All rights reserved.
//

import Foundation
import UIKit

class ImageTableViewCell : UITableViewCell {
  
  @IBOutlet weak var cirlceImageView: UIImageView?
  
  
  override func awakeFromNib() {
    super.awakeFromNib()
  }
  
  override func setSelected(selected: Bool, animated: Bool) {
    super.setSelected(selected, animated: animated)
  }
  
}
