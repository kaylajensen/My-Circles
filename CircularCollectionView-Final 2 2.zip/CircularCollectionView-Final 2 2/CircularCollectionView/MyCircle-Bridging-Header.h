//
//  MyCircle-Bridging-Header.h
//  ParseTesting
//
//  Created by Madeline Gilbert on 11/28/15.
//  Copyright © 2015 Kayla Kerney. All rights reserved.
//

#ifndef MyCircle_Bridging_Header_h
#define MyCircle_Bridging_Header_h

#import <Parse/Parse.h>
#import <Parse/PFObject+Subclass.h>
#import <Bolts/Bolts.h>

#endif /* MyCircle_Bridging_Header_h */
